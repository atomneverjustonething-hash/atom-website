import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@4.0.1";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
serve(async (req)=>{
 if(req.method==="OPTIONS") return new Response("ok",{headers:cors});
 if(req.method!=="POST") return new Response("Method not allowed",{status:405,headers:cors});
 try{
  const auth=req.headers.get("Authorization")||"";
  const expected=Deno.env.get("ATOM_NOTIFY_TOKEN");
  if(!expected||auth!==`Bearer ${expected}`) return new Response("Unauthorized",{status:401,headers:cors});
  const {kind,record}=await req.json();
  const resend=new Resend(Deno.env.get("RESEND_API_KEY"));
  const to=Deno.env.get("ATOM_NOTIFY_TO");
  const from=Deno.env.get("ATOM_NOTIFY_FROM");
  if(!to||!from||!Deno.env.get("RESEND_API_KEY")) throw new Error("Missing email environment variables");
  const subject=`New ATOM ${String(kind||"submission").replace(/[^a-z0-9 _-]/gi,"")} received`;
  const safe=JSON.stringify(record||{},null,2).slice(0,12000);
  const {error}=await resend.emails.send({from,to,subject,text:`A new ${kind||"submission"} was received by ATOM.\n\n${safe}`});
  if(error) throw new Error(error.message);
  return new Response(JSON.stringify({ok:true}),{headers:{...cors,"Content-Type":"application/json"}});
 }catch(e){return new Response(JSON.stringify({ok:false,error:String(e.message||e)}),{status:500,headers:{...cors,"Content-Type":"application/json"}})}
});
