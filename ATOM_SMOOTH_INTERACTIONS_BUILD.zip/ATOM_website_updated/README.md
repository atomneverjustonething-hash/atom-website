# ATOM — Netlify package

This is the static website package. Upload the **contents of this folder** (the `index.html` file and `assets` folder together) to Netlify Drop, or deploy the folder as the site publish directory.

## Before replacing the live site
1. Keep a copy of the currently deployed site ZIP/folder.
2. In the Supabase project connected in `index.html`, confirm Anonymous Sign-Ins are enabled.
3. Run `ATOM_FINAL_DATABASE_SETUP.sql` in Supabase SQL Editor. It is designed to be rerun and aligns the existing tables, anonymous-authenticated policies, private file bucket, and Realtime publication.
4. Confirm the bucket `atom-submissions` remains private.
5. Deploy a preview first if possible and run the test checklist below before changing the production domain.

## Included behavior
- Create, Impact, and Join forms submit to Supabase tables.
- Create attachments upload to the private `atom-submissions` bucket.
- Likes and comments/replies use Supabase anonymous Auth and the `atom_likes` / `atom_comments` tables.
- Realtime listeners refresh shared likes and discussions when Realtime is available.
- Saved items and language/theme preferences are browser-local, not shared across visitors.

## Important limitations
- Explore currently contains the sample posts embedded in the website. Newly submitted work is stored in Supabase but is **not automatically published into Explore**; it requires an admin review/publishing workflow that is not included in this static build.
- Email notifications are **not active**. The Edge Function source is included, but it still requires secure server-side secrets, a verified sender in Resend, deployment, and a trusted server-side trigger. Do not put a Resend key, Supabase service-role key, or other secret in `index.html`.
- This package has been statically inspected and JavaScript syntax-checked. It has not been connected to your live Supabase project from this environment, and cross-device/live form tests have not been performed. Do not treat static checks as a live production test.

## Test after deployment
- Submit one test work item without an attachment and verify a row in `submissions`.
- Submit one test work item with a small image and verify both the row and private Storage object.
- Submit a test Impact proposal and team application; verify their rows.
- Open the site in two browsers/devices. Like a sample post in one and confirm the count/state in the other.
- Add a comment and reply, then verify they appear in the other browser. Confirm only the author can edit/delete their comment.
- Confirm no submission form reports success unless Supabase confirms the insert.
