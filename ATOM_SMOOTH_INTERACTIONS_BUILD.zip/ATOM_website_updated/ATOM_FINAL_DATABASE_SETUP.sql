-- ATOM production schema/policies alignment. Safe to run after the earlier ATOM setup.
-- Uses anonymous Supabase Auth users (role authenticated), not the unauthenticated anon role.
create extension if not exists pgcrypto;

-- Existing submission tables are JSONB containers. The frontend also writes this nullable path.
alter table public.submissions add column if not exists attachment_path text;

-- Community tables (create if absent; preserve existing data).
create table if not exists public.atom_likes (
  id uuid primary key default gen_random_uuid(),
  post_id text not null,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  constraint atom_likes_one_per_user unique(post_id,user_id)
);
create index if not exists atom_likes_post_id_idx on public.atom_likes(post_id);

create table if not exists public.atom_comments (
  id uuid primary key default gen_random_uuid(),
  post_id text not null,
  parent_id uuid null references public.atom_comments(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  author_name text not null check (char_length(author_name) between 1 and 40),
  content text not null check (char_length(content) between 1 and 3000),
  edited boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists atom_comments_post_id_created_idx on public.atom_comments(post_id,created_at);

-- Anonymous Auth visitors have the authenticated database role.
alter table public.atom_likes enable row level security;
alter table public.atom_comments enable row level security;
alter table public.submissions enable row level security;
alter table public.impact_proposals enable row level security;
alter table public.team_applications enable row level security;

drop policy if exists "Anyone can read ATOM likes" on public.atom_likes;
create policy "Anyone can read ATOM likes" on public.atom_likes for select to anon, authenticated using (true);
drop policy if exists "Users can like as themselves" on public.atom_likes;
create policy "Users can like as themselves" on public.atom_likes for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users can remove their own likes" on public.atom_likes;
create policy "Users can remove their own likes" on public.atom_likes for delete to authenticated using (auth.uid() = user_id);

drop policy if exists "Anyone can read ATOM comments" on public.atom_comments;
create policy "Anyone can read ATOM comments" on public.atom_comments for select to anon, authenticated using (true);
drop policy if exists "Signed-in visitors can comment as themselves" on public.atom_comments;
create policy "Signed-in visitors can comment as themselves" on public.atom_comments for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Owners can edit their own comments" on public.atom_comments;
create policy "Owners can edit their own comments" on public.atom_comments for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Owners can delete their own comments" on public.atom_comments;
create policy "Owners can delete their own comments" on public.atom_comments for delete to authenticated using (auth.uid() = user_id);

-- Forms: allow both direct anonymous API access and anonymous-authenticated visitors.
-- INSERT only: public visitors cannot read applications or submissions.
drop policy if exists "ATOM public insert submissions" on public.submissions;
create policy "ATOM public insert submissions" on public.submissions for insert to anon, authenticated with check (true);
drop policy if exists "ATOM public insert impact proposals" on public.impact_proposals;
create policy "ATOM public insert impact proposals" on public.impact_proposals for insert to anon, authenticated with check (true);
drop policy if exists "ATOM public insert team applications" on public.team_applications;
create policy "ATOM public insert team applications" on public.team_applications for insert to anon, authenticated with check (true);

grant select, insert, delete on public.atom_likes to authenticated;
grant select, insert, update, delete on public.atom_comments to authenticated;
grant select on public.atom_likes, public.atom_comments to anon;
grant insert on public.submissions, public.impact_proposals, public.team_applications to anon, authenticated;

-- Keep the attachment bucket private. Uploaded files are not publicly readable.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('atom-submissions','atom-submissions',false,15728640,
  array['image/jpeg','image/png','image/webp','image/gif','application/pdf','video/mp4','video/quicktime'])
on conflict (id) do update set public=false, file_size_limit=15728640, allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists "ATOM visitors upload work files" on storage.objects;
create policy "ATOM visitors upload work files" on storage.objects for insert to anon, authenticated
with check (bucket_id='atom-submissions');

-- Realtime publication membership (idempotent).
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='atom_likes') then
    alter publication supabase_realtime add table public.atom_likes;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='atom_comments') then
    alter publication supabase_realtime add table public.atom_comments;
  end if;
end $$;
