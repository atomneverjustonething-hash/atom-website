# ATOM — final connected build (based on v29)

This package preserves the v29 design and adds a Supabase community layer.

## Included
- Create / Impact / Join form submission integration (existing JSONB-table integration).
- Private attachment upload to the `atom-submissions` bucket.
- Shared likes with one like per anonymous Supabase user and shared counts.
- Shared comments and nested replies. Anonymous Supabase Auth assigns a stable visitor identity; RLS permits edits/deletes only by the owner.
- Realtime refresh for likes and comments when Supabase Realtime is enabled for these tables.
- Supabase Edge Function source for email notifications. No secret key is included in the website or ZIP.

## Required one-time setup
1. In Supabase > Authentication > Providers, enable **Anonymous Sign-Ins**.
2. In SQL Editor, run `ATOM_FINAL_DATABASE_SETUP.sql`.
3. Ensure the existing `submissions`, `impact_proposals`, and `team_applications` tables each have a `data` JSONB column. The existing form connector inserts `{data: ...}` and `attachment_path` for submissions.
4. In Database > Replication / Publications, enable Realtime for `atom_likes` and `atom_comments` (if not already enabled). The app still reloads shared state on page load if Realtime is off.
5. Keep the `atom-submissions` storage bucket private. Do not expose a service-role key in browser code.

## Email notifications (secure setup)
The Edge Function source is in `supabase/functions/atom-notify/index.ts`. Deploy it from the Supabase CLI or Dashboard and configure server-side secrets:
- `RESEND_API_KEY` = a newly rotated Resend key (the key pasted into chat must be revoked; do not reuse it)
- `ATOM_NOTIFY_TO` = `atom.neverjustonething@gmail.com`
- `ATOM_NOTIFY_FROM` = a sender verified in Resend (requires domain verification; do not assume the test sender can deliver to arbitrary recipients)
- `ATOM_NOTIFY_TOKEN` = a long random token used only by a trusted server-side caller

Important: email notifications are **not yet live**. A trusted server-side trigger/caller must invoke this function after a successful insert. Do not put `ATOM_NOTIFY_TOKEN`, Resend API key, or Supabase service-role key in `index.html`. Configure a database webhook/trigger or a server-side submission function before treating email as operational.

## Testing checklist after setup
- Submit a test work entry with and without an attachment; verify a row in `submissions` and file in Storage.
- Submit an impact proposal and team application; verify rows in their respective tables.
- Open the same deployed site in two different browsers/devices: like an item in one and confirm count/state updates in the other.
- Add a comment and reply in one browser; confirm they appear in the other. Verify only the author can edit/delete.
- Verify the email trigger separately after configuring a verified sender and the server-side caller.

## Honest status
The code is packaged, but live database/email behavior cannot be certified from this offline build environment. Supabase schema, anonymous auth, storage policies, Resend sender verification, function deployment, and cross-device tests must be completed against your actual project before launch. Do not replace the existing live Netlify deploy until the preview passes all checks.

## Admin dashboard (added 6 November 2026)
- Deploy the complete `ATOM_website_updated` folder to Netlify.
- Open `https://YOUR-SITE/admin.html` to reach the private sign-in page.
- Sign in with the email/password account that was added to `public.atom_admins`.
- The dashboard checks membership in `public.atom_admins`; Supabase RLS remains the actual access control.
- Review submissions, team applications, and impact proposals. Accept/reject updates `review_status`.
- For an accepted submission, choose **Publish to Explore**. The public site reads approved rows from `public.atom_published_posts` and adds them to Explore after a page refresh.
- Do not add a service-role key, Resend API key, or ATOM notification token to browser files.
