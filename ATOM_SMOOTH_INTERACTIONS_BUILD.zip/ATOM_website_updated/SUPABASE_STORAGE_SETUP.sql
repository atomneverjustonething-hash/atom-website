-- Included in ATOM_FINAL_DATABASE_SETUP.sql. Kept as a reference for storage only.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('atom-submissions','atom-submissions',false,15728640,
  array['image/jpeg','image/png','image/webp','image/gif','application/pdf','video/mp4','video/quicktime'])
on conflict (id) do update set public=false, file_size_limit=15728640, allowed_mime_types=excluded.allowed_mime_types;
drop policy if exists "ATOM visitors upload work files" on storage.objects;
create policy "ATOM visitors upload work files" on storage.objects for insert to anon, authenticated
with check (bucket_id='atom-submissions');
